@echo off
setlocal
cd /d "%~dp0"
where javac >nul 2>nul
if errorlevel 1 (
    echo Java JDK 17 or newer is required. Get it from https://adoptium.net
    pause
    exit /b 1
)
if not exist stockfish.exe (
    echo NOTE: stockfish.exe not found in this folder - vs Bot and Analyze need it.
    echo.
)
if not exist out mkdir out
dir /s /b src\main\java\*.java > out\sources.txt
javac -encoding UTF-8 -d out @out\sources.txt
if errorlevel 1 (
    echo Compile failed.
    pause
    exit /b 1
)
start "" javaw -Dfile.encoding=UTF-8 -cp out chess.Main
endlocal
