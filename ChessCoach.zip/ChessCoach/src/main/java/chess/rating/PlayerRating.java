package chess.rating;

public class PlayerRating {
    private double value;
    private int games;

    public PlayerRating(double value, int games) { this.value = value; this.games = games; }
    public double value() { return value; }
    public int games() { return games; }

    /** score: 1 win, 0.5 draw, 0 loss. */
    public void update(double opponent, double score) {
        value = RatingCalculator.update(value, opponent, score, games < 20 ? 40 : 20);
        games++;
    }
}
