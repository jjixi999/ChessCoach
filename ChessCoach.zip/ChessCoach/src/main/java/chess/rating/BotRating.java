package chess.rating;

public final class BotRating {
    /** Value for Stockfish UCI_Elo (0 = full strength). */
    public static int engineElo(String level) { return level.equals("Max") ? 0 : Integer.parseInt(level); }
    /** Rating used when scoring games against the bot. */
    public static int rating(String level) { return level.equals("Max") ? 3200 : Integer.parseInt(level); }
}
