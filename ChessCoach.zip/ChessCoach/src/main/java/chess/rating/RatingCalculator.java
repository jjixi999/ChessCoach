package chess.rating;

public final class RatingCalculator {
    public static double expected(double a, double b) { return 1 / (1 + Math.pow(10, (b - a) / 400)); }
    public static double update(double rating, double opp, double score, int k) { return rating + k * (score - expected(rating, opp)); }
}
