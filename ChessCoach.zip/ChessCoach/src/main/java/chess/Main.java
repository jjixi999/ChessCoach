package chess;

import chess.analysis.*;
import chess.coaching.*;
import chess.engine.*;
import chess.game.*;
import chess.puzzle.*;
import chess.rating.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Main extends JPanel {
    static final int S = 80;
    enum Mode { FREE, BOT, PUZZLE }

    ChessGame game = new ChessGame();
    StockfishEngine eng;
    final PlayerProfile prof = PlayerProfile.load();
    final ChessCoach coach = new ChessCoach(prof);
    final PuzzleManager pm = new PuzzleManager();
    PuzzleSession ps;
    Mode mode = Mode.FREE;
    volatile boolean busy;
    boolean rated;
    int sr = -1, sc = -1;
    List<Move> hints = new ArrayList<>();
    String status = "Free play - White to move";
    final JComboBox<String> elo = new JComboBox<>(new String[]{"1500", "2000", "2500", "3000", "Max"});

    Main() {
        setPreferredSize(new Dimension(S * 8, S * 8 + 34));
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) { click(e.getY() / S, e.getX() / S); }
        });
    }

    boolean ensureEngine() {
        if (eng != null) return true;
        try { eng = new StockfishEngine(new File("stockfish.exe").exists() ? "stockfish.exe" : "stockfish"); return true; }
        catch (Exception e) { JOptionPane.showMessageDialog(this, "stockfish.exe not found in the ChessCoach folder."); return false; }
    }

    void click(int r, int c) {
        if (busy || r < 0 || r > 7 || c < 0 || c > 7 || (mode == Mode.BOT && !game.whiteTurn)) return;
        for (Move m : hints) if (m.r2() == r && m.c2() == c) { hints = new ArrayList<>(); sr = -1; play(m); return; }
        int p = game.b[r][c];
        hints = new ArrayList<>(); sr = -1;
        if (p != 0 && (p > 0) == game.whiteTurn && game.result() == GameResult.ONGOING) { sr = r; sc = c; hints = game.legal(r, c); }
        repaint();
    }

    void play(Move m) {
        if (mode == Mode.PUZZLE) {
            switch (ps.attempt(m)) {
                case WRONG -> status = "Not the best move - try again";
                case CORRECT -> status = "Correct! Keep going";
                case SOLVED -> status = "Solved! Puzzle rating " + Math.round(prof.puzzleRating.value());
            }
            prof.save(); repaint(); return;
        }
        game.play(m);
        update();
    }

    void update() {
        GameResult r = game.result();
        if (r != GameResult.ONGOING) {
            status = switch (r) { case WHITE_WINS -> "Checkmate - White wins"; case BLACK_WINS -> "Checkmate - Black wins"; default -> "Draw (stalemate)"; };
            if (mode == Mode.BOT && !rated) {
                rated = true;
                coach.recordGame(game, r == GameResult.WHITE_WINS ? 1 : r == GameResult.BLACK_WINS ? 0 : 0.5, BotRating.rating((String) elo.getSelectedItem()));
                status += " - rating " + Math.round(prof.rating.value());
            }
            repaint(); return;
        }
        status = (game.whiteTurn ? "White" : "Black") + " to move" + (game.inCheck() ? " (check)" : "");
        repaint();
        if (mode == Mode.BOT && !game.whiteTurn) botMove();
    }

    void botMove() {
        busy = true;
        String f = game.fen(), lv = (String) elo.getSelectedItem();
        new Thread(() -> {
            try {
                eng.setElo(BotRating.engineElo(lv));
                String best = eng.evaluate(f, "go movetime 1000").bestMove();
                SwingUtilities.invokeLater(() -> { game.playUci(best); busy = false; update(); });
            } catch (Exception ex) { busy = false; status = "Engine error: " + ex.getMessage(); repaint(); }
        }).start();
    }

    void analyze() {
        if (game.hist.isEmpty()) { show("Play some moves first."); return; }
        if (busy || !ensureEngine()) return;
        busy = true; status = "Analyzing..."; repaint();
        boolean mine = mode == Mode.BOT;
        new Thread(() -> {
            String text;
            try { text = coach.review(new GameAnalyzer().analyze(game, eng, 12), mine); }
            catch (Exception ex) { text = "Analysis failed: " + ex.getMessage(); }
            String t = text;
            SwingUtilities.invokeLater(() -> { busy = false; status = "Analysis done"; repaint(); show(t); });
        }).start();
    }

    void show(String t) {
        JTextArea ta = new JTextArea(t, 22, 36);
        ta.setEditable(false); ta.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        JOptionPane.showMessageDialog(this, new JScrollPane(ta), "ChessCoach", JOptionPane.PLAIN_MESSAGE);
    }

    JPanel bar() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        JButton free = new JButton("Free play"), bot = new JButton("vs Bot"), pz = new JButton("Puzzle"),
                an = new JButton("Analyze"), pf = new JButton("Profile");
        free.addActionListener(x -> { if (busy) return; game = new ChessGame(); mode = Mode.FREE; status = "Free play - White to move"; repaint(); });
        bot.addActionListener(x -> { if (busy || !ensureEngine()) return; game = new ChessGame(); mode = Mode.BOT; rated = false; status = "You are White"; repaint(); });
        pz.addActionListener(x -> { if (busy) return; ps = pm.next(prof.puzzleRating); game = ps.game; mode = Mode.PUZZLE;
            status = "Puzzle: find the best move for " + (game.whiteTurn ? "White" : "Black"); repaint(); });
        an.addActionListener(x -> analyze());
        pf.addActionListener(x -> show(coach.profileSummary()));
        p.add(free); p.add(bot); p.add(new JLabel("Bot Elo:")); p.add(elo); p.add(pz); p.add(an); p.add(pf);
        return p;
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setFont(new Font("Dialog", Font.PLAIN, 56));
        FontMetrics fm = g2.getFontMetrics();
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            g2.setColor((r + c) % 2 == 0 ? new Color(240, 217, 181) : new Color(181, 136, 99));
            if (r == sr && c == sc) g2.setColor(new Color(246, 246, 105));
            g2.fillRect(c * S, r * S, S, S);
            int p = game.b[r][c];
            if (p == 0) continue;
            String s = String.valueOf("♟♞♝♜♛♚".charAt(Math.abs(p) - 1));
            int x = c * S + (S - fm.stringWidth(s)) / 2, y = r * S + (S + fm.getAscent() - fm.getDescent()) / 2;
            if (p > 0) {
                g2.setColor(Color.BLACK);
                for (int dx = -2; dx <= 2; dx += 2) for (int dy = -2; dy <= 2; dy += 2) g2.drawString(s, x + dx, y + dy);
                g2.setColor(Color.WHITE);
            } else g2.setColor(Color.BLACK);
            g2.drawString(s, x, y);
        }
        g2.setColor(new Color(0, 160, 0, 140));
        for (Move m : hints) g2.fillOval(m.c2() * S + S / 3, m.r2() * S + S / 3, S / 3, S / 3);
        g2.setColor(Color.DARK_GRAY);
        g2.setFont(new Font("Dialog", Font.BOLD, 16));
        g2.drawString(status, 10, S * 8 + 22);
    }

    public static void main(String[] a) {
        SwingUtilities.invokeLater(() -> {
            Main m = new Main();
            JFrame f = new JFrame("ChessCoach");
            f.add(m.bar(), BorderLayout.NORTH);
            f.add(m);
            f.pack(); f.setResizable(false); f.setLocationRelativeTo(null);
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setVisible(true);
        });
    }
}
