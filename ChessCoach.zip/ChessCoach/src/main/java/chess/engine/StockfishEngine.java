package chess.engine;

import java.io.*;

/** UCI wrapper around stockfish.exe. */
public class StockfishEngine {
    private final Process p;
    private final BufferedWriter w;
    private final BufferedReader r;

    public StockfishEngine(String path) throws IOException {
        p = new ProcessBuilder(path).redirectErrorStream(true).start();
        w = new BufferedWriter(new OutputStreamWriter(p.getOutputStream()));
        r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        Runtime.getRuntime().addShutdownHook(new Thread(p::destroy));
        send("uci");
        String l;
        while ((l = r.readLine()) != null && !l.equals("uciok")) { }
    }

    private void send(String s) throws IOException { w.write(s + "\n"); w.flush(); }

    /** elo 0 = full strength, otherwise limited (Stockfish supports 1320-3190). */
    public synchronized void setElo(int elo) throws IOException {
        send("setoption name UCI_LimitStrength value " + (elo > 0));
        if (elo > 0) send("setoption name UCI_Elo value " + Math.max(1320, Math.min(3190, elo)));
    }

    public synchronized EngineEvaluation evaluate(String fen, String go) throws IOException {
        send("position fen " + fen);
        send(go);
        EngineLine best = new EngineLine(0, 0, "");
        String l;
        while ((l = r.readLine()) != null) {
            if (l.startsWith("info") && l.contains(" score ") && !l.contains("bound")) best = parse(l, best);
            if (l.startsWith("bestmove")) return new EngineEvaluation(l.split(" ")[1], best);
        }
        throw new IOException("Engine closed");
    }

    private static EngineLine parse(String l, EngineLine old) {
        String[] t = l.split(" ");
        int d = old.depth(), cp = old.cp();
        StringBuilder pv = new StringBuilder();
        for (int i = 0; i < t.length; i++) {
            if (t[i].equals("depth")) d = Integer.parseInt(t[i + 1]);
            else if (t[i].equals("score")) {
                int v = Integer.parseInt(t[i + 2]);
                cp = t[i + 1].equals("mate") ? (v > 0 ? 10000 - v : -10000 - v) : v;
            } else if (t[i].equals("pv")) {
                for (int j = i + 1; j < t.length; j++) pv.append(t[j]).append(' ');
                break;
            }
        }
        return new EngineLine(d, cp, pv.toString().trim());
    }
}
