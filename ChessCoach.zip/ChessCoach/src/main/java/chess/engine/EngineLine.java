package chess.engine;

/** One engine search line: depth, score in centipawns (side to move; mate = +-10000), principal variation. */
public record EngineLine(int depth, int cp, String pv) {}
