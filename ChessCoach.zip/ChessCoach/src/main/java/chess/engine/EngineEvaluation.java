package chess.engine;

public record EngineEvaluation(String bestMove, EngineLine line) {
    public int cp() { return line.cp(); }
}
