package chess.puzzle;

import chess.rating.PlayerRating;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Built-in puzzles plus any data/puzzles/*.txt lines of the form  FEN;move move;rating */
public class PuzzleManager {
    private final List<Puzzle> all = new ArrayList<>();
    private Puzzle last;

    public PuzzleManager() {
        add("6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1;a1a8;600");
        add("r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4;h5f7;400");
        add("rnbqkbnr/pppp1ppp/8/4p3/6P1/5P2/PPPPP2P/RNBQKBNR b KQkq - 0 2;d8h4;400");
        add("6rk/6pp/8/6N1/8/8/8/6K1 w - - 0 1;g5f7;900");
        try (var files = Files.list(Path.of("data", "puzzles"))) {
            for (Path f : files.filter(x -> x.toString().endsWith(".txt")).toList())
                for (String l : Files.readAllLines(f)) add(l);
        } catch (IOException e) { }
    }

    private void add(String line) {
        String[] t = line.trim().split(";");
        if (t.length < 2) return;
        all.add(new Puzzle(t[0], t[1].trim().split(" "), t.length > 2 ? Integer.parseInt(t[2].trim()) : 1000));
    }

    public PuzzleSession next(PlayerRating pr) {
        Puzzle pick = all.stream().filter(p -> p != last || all.size() == 1)
            .min(Comparator.comparingDouble(p -> Math.abs(p.rating() - pr.value()) + Math.random() * 150)).get();
        last = pick;
        return new PuzzleSession(pick, pr);
    }
}
