package chess.puzzle;

/** solution = alternating moves: yours, opponent reply, yours... (UCI). */
public record Puzzle(String fen, String[] solution, int rating) {}
