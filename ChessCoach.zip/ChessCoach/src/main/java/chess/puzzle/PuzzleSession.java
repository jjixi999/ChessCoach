package chess.puzzle;

import chess.game.*;
import chess.rating.PlayerRating;

public class PuzzleSession {
    public enum State { WRONG, CORRECT, SOLVED }

    public final ChessGame game;
    public final Puzzle puzzle;
    private final PlayerRating pr;
    private int idx;
    private String turnFen;
    private boolean failed;

    public PuzzleSession(Puzzle p, PlayerRating pr) {
        puzzle = p; this.pr = pr; game = new ChessGame(p.fen()); turnFen = p.fen();
    }

    public State attempt(Move m) {
        game.play(m);
        String[] sol = puzzle.solution();
        GameResult r = game.result();
        boolean mate = r == GameResult.WHITE_WINS || r == GameResult.BLACK_WINS;
        if (mate || (idx < sol.length && sol[idx].startsWith(m.uci()))) {
            idx++;
            if (mate || idx >= sol.length) { if (!failed) pr.update(puzzle.rating(), 1); return State.SOLVED; }
            game.playUci(sol[idx++]);
            turnFen = game.fen();
            return State.CORRECT;
        }
        if (!failed) pr.update(puzzle.rating(), 0);
        failed = true;
        game.setFen(turnFen);
        return State.WRONG;
    }
}
