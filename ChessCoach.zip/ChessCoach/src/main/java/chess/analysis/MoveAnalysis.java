package chess.analysis;

public record MoveAnalysis(int ply, boolean white, String uci, String best, String label, double loss, double accuracy) {
    public String line() {
        return (ply / 2 + 1) + (white ? ". " : "... ") + uci + "  " + label + (loss >= 5 ? "  (best: " + best + ")" : "");
    }
}
