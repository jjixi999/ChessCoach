package chess.analysis;

import chess.engine.StockfishEngine;
import chess.game.ChessGame;
import java.io.IOException;
import java.util.*;

public class GameAnalyzer {
    public List<MoveAnalysis> analyze(ChessGame g, StockfishEngine e, int depth) throws IOException {
        e.setElo(0);
        List<ChessGame.Played> h = new ArrayList<>(g.hist);
        int n = h.size();
        int[] sc = new int[n + 1];
        String[] best = new String[n + 1];
        for (int i = 0; i <= n; i++) {
            var ev = e.evaluate(i < n ? h.get(i).fenBefore() : g.fen(), "go depth " + depth);
            best[i] = ev.bestMove(); sc[i] = ev.cp();
        }
        List<MoveAnalysis> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            var pl = h.get(i);
            double pre = MistakeDetector.winPct(sc[i]), post = MistakeDetector.winPct(-sc[i + 1]);
            double loss = Math.max(0, pre - post);
            String label = MistakeDetector.classify(pl.uci().startsWith(best[i]) || pl.uci().equals(best[i]), loss, pl.sac(), pre, post);
            double acc = Math.max(0, Math.min(100, 103.1668 * Math.exp(-0.04354 * loss) - 3.1669));
            out.add(new MoveAnalysis(i, pl.fenBefore().contains(" w "), pl.uci(), best[i], label, loss, acc));
        }
        return out;
    }

    public static double accuracy(List<MoveAnalysis> a, boolean white) {
        return a.stream().filter(m -> m.white() == white).mapToDouble(MoveAnalysis::accuracy).average().orElse(0);
    }
}
