package chess.analysis;

public final class MistakeDetector {
    /** Lichess-style win percentage from a centipawn score. */
    public static double winPct(int cp) { return 50 + 50 * (2 / (1 + Math.exp(-0.00368208 * cp)) - 1); }

    /** pre/post = mover's win % before and after the move; loss = pre - post. */
    public static String classify(boolean isBest, double loss, boolean sac, double pre, double post) {
        if (sac && loss < 2 && post > 45 && pre < 85) return "Brilliant";
        if (isBest) return "Best";
        return loss < 2 ? "Excellent" : loss < 5 ? "Good" : loss < 10 ? "Inaccuracy" : loss < 20 ? "Mistake" : "Blunder";
    }

    public static boolean isError(String label) { return label.equals("Mistake") || label.equals("Blunder"); }
}
