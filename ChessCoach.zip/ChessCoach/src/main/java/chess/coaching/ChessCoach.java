package chess.coaching;

import chess.analysis.*;
import chess.game.*;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ChessCoach {
    private final PlayerProfile prof;
    private String lastKey = "";

    public ChessCoach(PlayerProfile prof) { this.prof = prof; }

    /** Text report. If learn is true, White's mistakes feed your weakness profile (once per game). */
    public String review(List<MoveAnalysis> a, boolean learn) {
        StringBuilder sb = new StringBuilder(String.format("Accuracy  White %.0f%%   Black %.0f%%\n",
            GameAnalyzer.accuracy(a, true), GameAnalyzer.accuracy(a, false)));
        Map<String, Integer> cnt = new TreeMap<>();
        for (MoveAnalysis m : a) if (m.white()) cnt.merge(m.label(), 1, Integer::sum);
        sb.append("White moves: ").append(cnt).append("\n\n");
        for (MoveAnalysis m : a) sb.append(m.line()).append('\n');
        String key = a.size() + ":" + a.get(a.size() - 1).uci();
        if (learn && !key.equals(lastKey)) { lastKey = key; prof.weakness.record(a, true); prof.save(); }
        if (learn) sb.append("\nCoach: ").append(prof.weakness.advice());
        return sb.toString();
    }

    /** Updates your rating against the bot and stores the game in data/games. */
    public void recordGame(ChessGame g, double score, int botRating) {
        prof.rating.update(botRating, score);
        prof.save();
        StringBuilder sb = new StringBuilder("score=" + score + " bot=" + botRating + "\n");
        for (var p : g.hist) sb.append(p.uci()).append(' ');
        try {
            Files.createDirectories(Path.of("data", "games"));
            String name = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").format(LocalDateTime.now());
            Files.writeString(Path.of("data", "games", "game-" + name + ".txt"), sb.toString());
        } catch (IOException e) { }
    }

    public String profileSummary() {
        return String.format("Game rating: %.0f (%d games)\nPuzzle rating: %.0f (%d puzzles)\n\n%s\n%s",
            prof.rating.value(), prof.rating.games(), prof.puzzleRating.value(), prof.puzzleRating.games(),
            prof.weakness.summary(), prof.weakness.advice());
    }
}
