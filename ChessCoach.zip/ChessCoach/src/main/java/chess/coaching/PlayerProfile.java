package chess.coaching;

import chess.rating.PlayerRating;
import java.io.*;
import java.nio.file.*;
import java.util.Properties;

/** Saved in data/profile.properties. */
public class PlayerProfile {
    static final Path FILE = Path.of("data", "profile.properties");
    public PlayerRating rating = new PlayerRating(1200, 0), puzzleRating = new PlayerRating(1000, 0);
    public final WeaknessProfile weakness = new WeaknessProfile();

    public static PlayerProfile load() {
        PlayerProfile p = new PlayerProfile();
        Properties pr = new Properties();
        try (var in = Files.newInputStream(FILE)) {
            pr.load(in);
            p.rating = new PlayerRating(d(pr, "rating", 1200), (int) d(pr, "ratingGames", 0));
            p.puzzleRating = new PlayerRating(d(pr, "puzzle", 1000), (int) d(pr, "puzzleGames", 0));
            for (int i = 0; i < 3; i++) { p.weakness.errors[i] = (int) d(pr, "err" + i, 0); p.weakness.moves[i] = (int) d(pr, "mv" + i, 0); }
        } catch (Exception e) { }
        return p;
    }

    private static double d(Properties p, String k, double def) { return Double.parseDouble(p.getProperty(k, "" + def)); }

    public void save() {
        Properties pr = new Properties();
        pr.setProperty("rating", "" + rating.value()); pr.setProperty("ratingGames", "" + rating.games());
        pr.setProperty("puzzle", "" + puzzleRating.value()); pr.setProperty("puzzleGames", "" + puzzleRating.games());
        for (int i = 0; i < 3; i++) { pr.setProperty("err" + i, "" + weakness.errors[i]); pr.setProperty("mv" + i, "" + weakness.moves[i]); }
        try {
            Files.createDirectories(FILE.getParent());
            try (var out = Files.newOutputStream(FILE)) { pr.store(out, "ChessCoach profile"); }
        } catch (IOException e) { }
    }
}
