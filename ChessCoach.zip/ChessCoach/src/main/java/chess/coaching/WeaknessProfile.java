package chess.coaching;

import chess.analysis.*;
import java.util.*;

/** Tracks mistakes/blunders by game phase (opening <10 moves, middlegame <30, endgame after). */
public class WeaknessProfile {
    static final String[] PHASES = {"opening", "middlegame", "endgame"};
    static final String[] TIPS = {
        "Review your opening moves: develop pieces, control the center, castle early.",
        "Before each move in the middlegame, check what your opponent's last move threatens.",
        "Practice endgames: king activity and passed pawns decide most of them."};
    public final int[] errors = new int[3], moves = new int[3];

    static int phase(int ply) { return ply < 20 ? 0 : ply < 60 ? 1 : 2; }

    public void record(List<MoveAnalysis> a, boolean white) {
        for (MoveAnalysis m : a) if (m.white() == white) {
            moves[phase(m.ply())]++;
            if (MistakeDetector.isError(m.label())) errors[phase(m.ply())]++;
        }
    }

    public String advice() {
        int total = Arrays.stream(moves).sum();
        if (total < 10) return "Play and analyze a few more games so I can spot your patterns.";
        int w = 0; double worst = -1;
        for (int i = 0; i < 3; i++) {
            double rate = moves[i] < 3 ? 0 : (double) errors[i] / moves[i];
            if (rate > worst) { worst = rate; w = i; }
        }
        if (worst <= 0) return "No mistakes so far. Nice! Try a higher bot level.";
        return String.format("Weakest phase: %s (%.0f%% of moves were mistakes/blunders). %s", PHASES[w], worst * 100, TIPS[w]);
    }

    public String summary() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++) sb.append(PHASES[i]).append(": ").append(errors[i]).append(" errors / ").append(moves[i]).append(" moves\n");
        return sb.toString();
    }
}
