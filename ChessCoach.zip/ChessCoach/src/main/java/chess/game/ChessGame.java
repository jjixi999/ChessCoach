package chess.game;

import java.util.*;

/** Board, rules (castling, en passant, auto-queen), FEN and move history. Pieces: +white -black, 1=P 2=N 3=B 4=R 5=Q 6=K. */
public class ChessGame {
    public static final String START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    public record Played(String fenBefore, String uci, boolean sac) {}

    public int[][] b = new int[8][8];
    public boolean whiteTurn = true;
    public final List<Played> hist = new ArrayList<>();
    private boolean[] moved = new boolean[6]; // wK, wRa, wRh, bK, bRa, bRh
    private int epR = -1, epC = -1;

    public ChessGame() { this(START); }
    public ChessGame(String fen) { setFen(fen); }

    public void setFen(String f) {
        String[] t = f.split(" ");
        b = new int[8][8]; moved = new boolean[]{true, true, true, true, true, true};
        String[] rows = t[0].split("/");
        for (int r = 0; r < 8; r++) {
            int c = 0;
            for (char ch : rows[r].toCharArray()) {
                if (Character.isDigit(ch)) c += ch - '0';
                else { int v = "pnbrqk".indexOf(Character.toLowerCase(ch)) + 1; b[r][c++] = Character.isUpperCase(ch) ? v : -v; }
            }
        }
        whiteTurn = t[1].equals("w");
        String cs = t.length > 2 ? t[2] : "-";
        if (cs.contains("K")) { moved[0] = false; moved[2] = false; }
        if (cs.contains("Q")) { moved[0] = false; moved[1] = false; }
        if (cs.contains("k")) { moved[3] = false; moved[5] = false; }
        if (cs.contains("q")) { moved[3] = false; moved[4] = false; }
        epR = epC = -1;
        if (t.length > 3 && !t[3].equals("-")) { epC = t[3].charAt(0) - 'a'; epR = 8 - (t[3].charAt(1) - '0'); }
        hist.clear();
    }

    public String fen() {
        StringBuilder s = new StringBuilder();
        for (int r = 0; r < 8; r++) {
            int e = 0;
            for (int c = 0; c < 8; c++) {
                int p = b[r][c];
                if (p == 0) { e++; continue; }
                if (e > 0) { s.append(e); e = 0; }
                char ch = "pnbrqk".charAt(Math.abs(p) - 1);
                s.append(p > 0 ? Character.toUpperCase(ch) : ch);
            }
            if (e > 0) s.append(e);
            if (r < 7) s.append('/');
        }
        String cs = "";
        if (!moved[0] && b[7][4] == 6) { if (!moved[2] && b[7][7] == 4) cs += "K"; if (!moved[1] && b[7][0] == 4) cs += "Q"; }
        if (!moved[3] && b[0][4] == -6) { if (!moved[5] && b[0][7] == -4) cs += "k"; if (!moved[4] && b[0][0] == -4) cs += "q"; }
        String ep = epR < 0 ? "-" : "" + (char) ('a' + epC) + (8 - epR);
        return s + (whiteTurn ? " w " : " b ") + (cs.isEmpty() ? "-" : cs) + " " + ep + " 0 1";
    }

    public void playUci(String u) { play(Move.parse(u)); }

    public void play(Move m) {
        int r1 = m.r1(), c1 = m.c1(), r2 = m.r2(), c2 = m.c2();
        int p = b[r1][c1], ap = Math.abs(p), cap = Math.abs(b[r2][c2]);
        String fb = fen();
        if (ap == 1 && c2 == epC && r2 == epR && b[r2][c2] == 0) b[r1][c2] = 0;
        epR = epC = -1;
        if (ap == 1 && Math.abs(r2 - r1) == 2) { epR = (r1 + r2) / 2; epC = c1; }
        if (ap == 6 && Math.abs(c2 - c1) == 2) {
            int rc = c2 > c1 ? 7 : 0, nc = c2 > c1 ? 5 : 3;
            b[r1][nc] = b[r1][rc]; b[r1][rc] = 0;
        }
        if (ap == 6) moved[p > 0 ? 0 : 3] = true;
        if (ap == 4 && c1 == 0) moved[p > 0 ? 1 : 4] = true;
        if (ap == 4 && c1 == 7) moved[p > 0 ? 2 : 5] = true;
        b[r2][c2] = p; b[r1][c1] = 0;
        boolean promo = ap == 1 && (r2 == 0 || r2 == 7);
        if (promo) b[r2][c2] = p * 5;
        int[] V = {0, 1, 3, 3, 5, 9, 0};
        boolean sac = ap > 1 && ap < 6 && V[ap] - V[cap] >= 2 && attacked(r2, c2, p < 0);
        hist.add(new Played(fb, m.uci() + (promo ? "q" : ""), sac));
        whiteTurn = !whiteTurn;
    }

    public GameResult result() {
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++)
            if (b[r][c] != 0 && (b[r][c] > 0) == whiteTurn && !legal(r, c).isEmpty()) return GameResult.ONGOING;
        if (inCheck(whiteTurn)) return whiteTurn ? GameResult.BLACK_WINS : GameResult.WHITE_WINS;
        return GameResult.DRAW;
    }

    public boolean inCheck() { return inCheck(whiteTurn); }

    public List<Move> legal(int r, int c) {
        List<Move> out = new ArrayList<>();
        int p = b[r][c];
        for (int[] m : pseudo(r, c, true)) {
            int[][] save = copy();
            if (Math.abs(p) == 1 && m[1] == epC && m[0] == epR && b[m[0]][m[1]] == 0) b[r][m[1]] = 0;
            b[m[0]][m[1]] = p; b[r][c] = 0;
            if (!inCheck(p > 0)) out.add(new Move(r, c, m[0], m[1]));
            b = save;
        }
        return out;
    }

    private int[][] copy() { int[][] n = new int[8][]; for (int i = 0; i < 8; i++) n[i] = b[i].clone(); return n; }

    private boolean inCheck(boolean white) {
        int k = white ? 6 : -6, kr = 0, kc = 0;
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) if (b[r][c] == k) { kr = r; kc = c; }
        return attacked(kr, kc, !white);
    }

    private boolean attacked(int r, int c, boolean byWhite) {
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            int p = b[i][j];
            if (p == 0 || (p > 0) != byWhite) continue;
            for (int[] m : pseudo(i, j, false)) if (m[0] == r && m[1] == c) return true;
        }
        return false;
    }

    private boolean in(int r, int c) { return r >= 0 && r < 8 && c >= 0 && c < 8; }

    private List<int[]> pseudo(int r, int c, boolean castle) {
        List<int[]> o = new ArrayList<>();
        int p = b[r][c], t = Math.abs(p), d = p > 0 ? -1 : 1;
        if (t == 1) {
            if (castle && in(r + d, c) && b[r + d][c] == 0) {
                o.add(new int[]{r + d, c});
                if (r == (p > 0 ? 6 : 1) && b[r + 2 * d][c] == 0) o.add(new int[]{r + 2 * d, c});
            }
            for (int dc = -1; dc <= 1; dc += 2) {
                int nr = r + d, nc = c + dc;
                if (!in(nr, nc)) continue;
                if (!castle) { o.add(new int[]{nr, nc}); continue; }
                if ((b[nr][nc] != 0 && (b[nr][nc] > 0) != (p > 0)) || (nr == epR && nc == epC)) o.add(new int[]{nr, nc});
            }
            return o;
        }
        int[][] kn = {{1, 2}, {2, 1}, {-1, 2}, {-2, 1}, {1, -2}, {2, -1}, {-1, -2}, {-2, -1}};
        int[][] dg = {{1, 1}, {1, -1}, {-1, 1}, {-1, -1}}, st = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        if (t == 2) for (int[] k : kn) add(o, r + k[0], c + k[1], p);
        else if (t == 6) {
            for (int[] k : dg) add(o, r + k[0], c + k[1], p);
            for (int[] k : st) add(o, r + k[0], c + k[1], p);
            if (castle) castling(o, r, c, p);
        } else {
            List<int[]> dirs = new ArrayList<>();
            if (t != 4) dirs.addAll(Arrays.asList(dg));
            if (t != 3) dirs.addAll(Arrays.asList(st));
            for (int[] k : dirs) {
                int nr = r + k[0], nc = c + k[1];
                while (in(nr, nc)) {
                    add(o, nr, nc, p);
                    if (b[nr][nc] != 0) break;
                    nr += k[0]; nc += k[1];
                }
            }
        }
        return o;
    }

    private void add(List<int[]> o, int nr, int nc, int p) {
        if (in(nr, nc) && (b[nr][nc] == 0 || (b[nr][nc] > 0) != (p > 0))) o.add(new int[]{nr, nc});
    }

    private void castling(List<int[]> o, int r, int c, int p) {
        boolean w = p > 0; int i = w ? 0 : 3, row = w ? 7 : 0;
        if (moved[i] || r != row || c != 4 || inCheck(w)) return;
        if (!moved[i + 2] && b[row][5] == 0 && b[row][6] == 0 && b[row][7] == (w ? 4 : -4)
            && !attacked(row, 5, !w) && !attacked(row, 6, !w)) o.add(new int[]{row, 6});
        if (!moved[i + 1] && b[row][1] == 0 && b[row][2] == 0 && b[row][3] == 0 && b[row][0] == (w ? 4 : -4)
            && !attacked(row, 3, !w) && !attacked(row, 2, !w)) o.add(new int[]{row, 2});
    }
}
