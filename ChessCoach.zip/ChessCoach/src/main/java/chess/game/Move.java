package chess.game;

public record Move(int r1, int c1, int r2, int c2) {
    public String uci() { return "" + (char) ('a' + c1) + (8 - r1) + (char) ('a' + c2) + (8 - r2); }
    public static Move parse(String u) {
        return new Move(8 - (u.charAt(1) - '0'), u.charAt(0) - 'a', 8 - (u.charAt(3) - '0'), u.charAt(2) - 'a');
    }
}
